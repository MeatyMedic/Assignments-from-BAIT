﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Threading;

namespace Animal_Farm
{
    class Hashtable : Animals_Farm
    {
        // Iterate through the keys of the hashtable
        // Use profitability to compare
        // Insert the values here
        // Insert key into array
        // Pointer.getprofitability swap if pointer is bigger - Used bubble Sort
        // Hashtable should have everything, wont need to access the database for calculations/manipulation.
        // Dictionary examples has iteration through the hastable

        private static double goat_Milk_Price;     // Per litre (local currency)
        private static double cow_Milk_Price;      // Per litre (local currency)
        private static double sheep_Wool_Price;    // Per Kg (local currency)
        private static double water_Price;         // In Cube (local currency)
        private static double government_Tax;      // Per KG (not including dogs)
        private static double jersey_Cow_Tax;      // Per Jersy cow

        // Creates Dictionary for Hashtable
        public static Dictionary<int, Animals_Farm> allAnimals = new Dictionary<int, Animals_Farm>();

        // Data Dictionary is being set here
        static public String displayAnimalInfo(Animals_Farm animal)
        {
            //Animals_Farm fa = allAnimals[id];
            return (animal.displayInfo());
        }

        // Public constructor for the Hashtable Class- Inherits from Animals_Farm as it's parent class
        public Hashtable(int ID, double daily_Cost, double amt_water, double weight, int age, String colour, String type)
            : base(ID, daily_Cost, amt_water, age, colour, weight, type)
        {

        }

        // Generate hastable for each of the classes
        public static void generateHashTable()
        {
            cowInsert();
            GoatInsert();
            SheepInsert();
            DogInsert();
        }

        // Method to insert Cows into the Hashtable
        public static void cowInsert()
        {
            // Uses Dictionary fa - Farm animals
            Animals_Farm fa;

            // Establishes a connection to the database - CHANGE THE FILE LOCATION TO WHERE NEEDED
            String connection_String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='D:\\2018 Semester 2\\COMP609 1802 - Application development\\Animal Farm\\DATABASE\\FarmInfomation.accdb';Persist Security Info=False";
            String error_message = "";

            //Stores the query
            String query = "";
            OleDbConnection connection = null;

            try
            {
                connection = new OleDbConnection(connection_String);
                connection.Open();

                // Sets query to grab what you want from the database to be inserted into the Hashtable
                query = "SELECT * FROM Cow";
                OleDbCommand command = new OleDbCommand(query, connection);

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Sets what each of the rows from Database insert into and the rows to insert from
                        int ID = int.Parse(reader["ID"].ToString());
                        double amt_Water = double.Parse(reader["Amount of water"].ToString());
                        double daily_Cost = double.Parse(reader["Daily Cost"].ToString());
                        double weight = double.Parse(reader["Weight"].ToString());
                        int age = int.Parse(reader["Age"].ToString());
                        string Colour = reader["Color"].ToString();
                        double amt_Milk = double.Parse(reader["Amount of milk"].ToString());
                        bool isJersy = bool.Parse(reader["Is jersy"].ToString());

                        // If statement to diffrentiate between jersey cow and normal cow
                        if (isJersy == true)
                        {
                            // Uses Dictionary FA to add animal class to the Hashtable with these parameters
                            fa = new Jersey_Cow(ID, amt_Water, weight, age, Colour, daily_Cost, "Jersy Cow", amt_Milk, isJersy);
                            allAnimals.Add(ID, fa);
                        }
                        else
                        {
                            fa = new Cows(ID, amt_Water, weight, age, Colour, daily_Cost, "Cow", amt_Milk, isJersy);
                            allAnimals.Add(ID, fa);
                        }

                    }
                }
                // Close the Connection
                connection.Close();
            }
            // Catch Exception to find any errors
            catch (Exception ex)
            {
                error_message = ex.Message;
                Console.Write(error_message);
            }
        }

        // Method to insert Goats into the Hashtable
        public static void GoatInsert()
        {
            // Uses Dictionary fa - Farm animals
            Animals_Farm fa;

            // Establishes a connection to the database
            String connection_String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='D:\\2018 Semester 2\\COMP609 1802 - Application development\\Animal Farm\\DATABASE\\FarmInfomation.accdb';Persist Security Info=False";
            String error_message = "";

            //Stores the query
            String query = "";
            OleDbConnection connection = null;

            try
            {
                connection = new OleDbConnection(connection_String);
                connection.Open();

                // Sets query to grab what you want from the database to be inserted into the Hashtable
                query = "SELECT * FROM Goat";
                OleDbCommand command = new OleDbCommand(query, connection);

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Sets what each of the rows from Database insert into and the rows to insert from
                        int ID = int.Parse(reader["ID"].ToString());
                        double amt_Water = double.Parse(reader["Amount of water"].ToString());
                        double daily_Cost = double.Parse(reader["Daily Cost"].ToString());
                        double weight = double.Parse(reader["Weight"].ToString());
                        int age = int.Parse(reader["Age"].ToString());
                        string Colour = reader["Color"].ToString();
                        double amt_Milk = double.Parse(reader["Amount of milk"].ToString());

                        // Uses Dictionary FA to add animal class to the Hashtable with these parameters
                        fa = new Goats(ID, amt_Water, weight, age, Colour, daily_Cost, "Goat", amt_Milk);
                        allAnimals.Add(ID, fa);
                    }
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                error_message = ex.Message;
                Console.Write(error_message);
            }
        }

        // Method to insert Sheep into the Hashtable
        public static void SheepInsert()
        {
            // Uses Dictionary fa - Farm animals
            Animals_Farm fa;

            // Establishes a connection to the database
            String connection_String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='D:\\2018 Semester 2\\COMP609 1802 - Application development\\Animal Farm\\DATABASE\\FarmInfomation.accdb';Persist Security Info=False";
            String error_message = "";

            //Stores the query
            String query = "";
            OleDbConnection connection = null;

            try
            {
                connection = new OleDbConnection(connection_String);
                connection.Open();

                // Sets query to grab what you want from the database to be inserted into the Hashtable
                query = "SELECT * FROM Sheep";
                OleDbCommand command = new OleDbCommand(query, connection);

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Sets what each of the rows from Database insert into and the rows to insert from
                        int ID = int.Parse(reader["ID"].ToString());
                        double amt_Water = double.Parse(reader["Amount of water"].ToString());
                        double daily_Cost = double.Parse(reader["Daily Cost"].ToString());
                        double weight = double.Parse(reader["Weight"].ToString());
                        int age = int.Parse(reader["Age"].ToString());
                        string Colour = reader["Color"].ToString();
                        double amt_Wool = double.Parse(reader["Amount of wool"].ToString());

                        // Uses Dictionary FA to add animal class to the Hashtable with these parameters
                        fa = new Sheep(ID, amt_Water, weight, age, Colour, daily_Cost, "Sheep", amt_Wool);
                        allAnimals.Add(ID, fa);
                    }
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                error_message = ex.Message;
                Console.Write(error_message);
            }
        }

        // Method to insert Dogs into the Hashtable
        public static void DogInsert()
        {
            // Uses Dictionary fa - Farm animals
            Animals_Farm fa;

            // Establishes a connection to the database
            String connection_String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='D:\\2018 Semester 2\\COMP609 1802 - Application development\\Animal Farm\\DATABASE\\FarmInfomation.accdb';Persist Security Info=False";
            String error_message = "";

            //Stores the query
            String query = "";
            OleDbConnection connection = null;

            try
            {
                connection = new OleDbConnection(connection_String);
                connection.Open();

                // Sets query to grab what you want from the database to be inserted into the Hashtable
                query = "SELECT * FROM Dog";
                OleDbCommand command = new OleDbCommand(query, connection);

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Sets what each of the rows from Database insert into and the rows to insert from
                        int ID = int.Parse(reader["ID"].ToString());
                        double amt_Water = double.Parse(reader["Amount of water"].ToString());
                        double weight = double.Parse(reader["Weight"].ToString());
                        int age = int.Parse(reader["Age"].ToString());
                        string Colour = reader["Color"].ToString();
                        double daily_Cost = double.Parse(reader["Daily Cost"].ToString());

                        // Uses Dictionary FA to add animal class to the Hashtable with these parameters
                        fa = new Dog(ID, amt_Water, weight, age, Colour, daily_Cost, "Dog");
                        allAnimals.Add(ID, fa);
                    }
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                error_message = ex.Message;
                Console.Write(error_message);
            }
        }

        // Method to insert Rates into the Hashtable
        public static void getRates_Prices()
        {
            // Establishes a connection to the database
            String connection_String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='D:\\2018 Semester 2\\COMP609 1802 - Application development\\Animal Farm\\DATABASE\\FarmInfomation.accdb';Persist Security Info=False";
            String error_message = "";

            //Stores the query
            String query = "";
            OleDbConnection connection = null;

            try
            {
                connection = new OleDbConnection(connection_String);
                connection.Open();

                // Sets query to grab what you want from the database to be inserted into the Hashtable
                query = "SELECT * FROM Rates;";
                OleDbCommand command = new OleDbCommand(query, connection);

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        // Sets what each of the rows from Database insert into and the rows to insert from
                        string commoditty = reader["Commodity"].ToString();
                        double price = double.Parse(reader["Price"].ToString());

                        // Requires static for object reference
                        // If satements to make price equal to the price of the row associated with the row name - (Goat milk price row, is now goat_Milk_Price variable for use)

                        // Switch Case, for more better formatting instead of if else, else if
                        switch(commoditty)
                        {
                            case "Goat milk price":
                                goat_Milk_Price = price;
                                break;
                            case "Sheep wool price":
                                sheep_Wool_Price = price;
                                break;
                            case "Water price":
                                water_Price = price;
                                break;
                            case "Government tax per kg":
                                government_Tax = price;
                                break;
                            case "Jersy cow tax":
                                jersey_Cow_Tax = price;
                                break;
                            case "Cow milk price":
                                cow_Milk_Price = price;
                                break;
                        }
                    }
                }
                connection.Close();
            }
            catch (Exception ex)
            {
                error_message = ex.Message;
                Console.Write(error_message);
            }
        }


        // CalculatIons, The prices and everything else here.

        // Total Milk per day for the the farm animals
        public static String getMilkPerDay()
        {
            double totalMilk = 0;

            // For loop using key(id,) in all animals
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                // If animal value type equals to "Cow" or "Jersy Cow" or "Goat"
                if (animal.Value.a_Type.Equals("Cow") || animal.Value.a_Type.Equals("Jersy Cow") || animal.Value.a_Type.Equals("Goat"))
                {
                    // totaMilk = animal value get milk from each animal - Grabs milk from each of those animals using getMilk
                    totalMilk += animal.Value.getMilk();
                }
            }
            // Return string + 2 decimal point formatting
            return ("Total Milk per day for Goats and Cows is: " + totalMilk.ToString("F") + "L");
        }

        // Total Milk per day for the Cows
        public static double getCowMilkPerDay()
        {
            double totalMilk = 0;
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (animal.Value.a_Type.Equals("Cow"))
                {
                    totalMilk += animal.Value.getMilk();
                }
            }
            return (totalMilk);
        }

        // Total Milk per day for the Goats
        public static double getGoatMilkPerDay()
        {
            double totalMilk = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (animal.Value.a_Type.Equals("Goat"))
                {
                    totalMilk += animal.Value.getMilk();
                }
            }
            return (totalMilk);
        }

        // Total Wool per day for the Sheep
        public static double getWoolPerDay()
        {
            double totalWool = 0;
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (animal.Value.a_Type.Equals("Sheep"))
                {
                    totalWool += animal.Value.getWool();
                }
            }
            return (totalWool);
        }

        // Average Age of all Animals not including dogs
        public static String getAverageAge()
        {
            // Initializing Variables
            int age = 0;
            int averageAge = 0;
            int counter = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                // If animals type is NOT Dog (Every other animal except dog)
                if (!animal.Value.a_Type.Equals("Dog"))
                {
                    // Average age is set, Counter increments
                    averageAge += animal.Value.a_Age;
                    counter++;
                }
                // Finding average age, age divided by amount of animals used
                age = averageAge / counter;
            }
            return ("The Average Age of All Farm animals excluding dogs: " + age);
        }

        // Gets total weight of the all the animals on the Animal_Farm
        public static double getTotalWeight()
        {
            double totalWeight = 0;
            // For all the animals in the Hashtable
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                // Sets total weight for each animal
                totalWeight += animal.Value.a_Weight;
            }
            return (totalWeight);
        }

        // Counts the number of Jersy Cows on the Animal_Farm
        public static double getNumberJersyCow()
        {
            int countJersyCow = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                // If animal type = "Jersy Cow" then counter increments
                if (animal.Value.a_Type.Equals("Jersy Cow"))
                {
                    countJersyCow++;
                }
            }
            // Returns the number of Jersy Cows in the Hashtable
            return (countJersyCow);
        }

        // Gets amount of water per day for each animal on the Animal_Farm
        public static double getWaterPerDay()
        {
            double amt_WaterPerDay = 0;
            // For each of the animals in the Hashtable
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                // Set water amount as their water per day
                amt_WaterPerDay += animal.Value.a_Amt_Water;
            }
            return (amt_WaterPerDay);
        }

        // Calculates the daily cost + amount of water per day on the Animal_Farm **** Side note notsure if the + is supposed to be there
        public static double getDailyCosts()
        {
            double costsDaily = 0;
            // For all animals
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                // Get Daily cost + water cost
                costsDaily += animal.Value.a_Daily_Cost + animal.Value.a_Amt_Water;
            }
            return (costsDaily);
        }

        // To Caluclate wheather the profit is in the green or the red (Positive, negative)
        public static String getProfitPerDay()
        {
            // Total Cow Milk
            double totalCowMilk = getCowMilkPerDay() * cow_Milk_Price;
            // Total Goat Milk
            double totalGoatMilk = getGoatMilkPerDay() * goat_Milk_Price;
            // Total Animal Milk
            double totalMilk = totalCowMilk + totalGoatMilk;
            // Total Sheep Wool
            double totalWool = getWoolPerDay() * sheep_Wool_Price;
            // Total Daily Costs
            double totalDailyCosts = getDailyCosts();
            // Total Weight of Animals
            double totalWeight = getTotalWeight() * government_Tax;
            // Total Number of Jersy Cows
            double totalJersyCow = getNumberJersyCow() * jersey_Cow_Tax;
            // Total Price of Water per Day
            double totalWater = getWaterPerDay() * Math.Pow(water_Price, 3);
            // Profit - Costs
            double GreenOrRed = (((totalMilk + totalWool) - (totalDailyCosts + totalWater)) - totalWeight) - totalJersyCow;

            // If statement to change the string output based on whether it was profit/loss
            if (GreenOrRed >= 0)
            {
                return ("Total Profit of the farm for Today is: $" + GreenOrRed.ToString("F"));
            }
            else
            {
                return ("Total Loss of the farm for Today is: $" + GreenOrRed.ToString("F"));
            }

        }

        // To find the ID of the animals and return the displayInfo() related to that animal ID
        public static string getID(int id)
        {
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (animal.Value.a_ID == (id))
                {
                    return (displayAnimalInfo(animal.Value));
                }
            }
            return ("Invalid ID: " + id);
        }

        // To Calculate the Tax Paid per Month of all animals
        public static String getTaxPerMonth()
        {
            double taxPerMonth = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (!animal.Value.a_Type.Equals("Dog"))
                {
                    taxPerMonth = ((getTotalWeight() * government_Tax) + (getNumberJersyCow() * jersey_Cow_Tax) * 30);// Find more accuarte way to calculate monthly

                }
            }
            return ("Total Tax per Month is: $" + taxPerMonth.ToString("F"));
        }

        // To Calculat the Tax per Day for All Jersy Cows, per Jersy Cow
        public static String getJersyCowTax()
        {
            double taxPerDay = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (animal.Value.a_Type.Equals("Jersy Cow"))
                {
                    taxPerDay = getNumberJersyCow() * jersey_Cow_Tax;
                }
            }
            return ("Total Tax per day for Jersy Cows is: $" + taxPerDay);
        }

        // Comparing Cow and Goat against Sheep to find better profit margin
        public static String getCowGoatSheepProfit()
        {
            // Initializing of Variables
            double costs = 0;
            double cowGoatProfit = 0;
            double sheepProfit = 0;

            double total_Cow_Goat_Profit = 0;
            double average_Cow_Goat_Profit = 0;

            double total_Sheep = 0;
            double average_Sheep_Profit = 0;

            int num_Cow_Goat = 0;
            int num_Sheep = 0;


            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hashtable
            {
                // If animal is Cow Jersy Cow or Goat then calculate the costs, profit - costs then increment cows and goats
                if (animal.Value.a_Type.Equals("Cow") || animal.Value.a_Type.Equals("Is jersy") || animal.Value.a_Type.Equals("Goat"))
                {
                    costs = animal.Value.a_Daily_Cost + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3)) + (animal.Value.a_Weight * government_Tax) + getNumberJersyCow();
                    cowGoatProfit = (getCowMilkPerDay() * cow_Milk_Price) + (getGoatMilkPerDay() * goat_Milk_Price);
                    num_Cow_Goat++;
                }
                // If animal is sheep, Calculate the costs, profit - costs then increment sheep number
                else if (animal.Value.a_Type.Equals("Sheep"))
                {
                    costs = animal.Value.a_Daily_Cost + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3)) + (animal.Value.a_Weight * government_Tax);
                    sheepProfit = (getWoolPerDay() * sheep_Wool_Price);
                    num_Sheep++;
                }

            }
            // Total profit Between Cows and Goats
            total_Cow_Goat_Profit = cowGoatProfit - costs;

            // Average Profit for Cows and Goats
            average_Cow_Goat_Profit = total_Cow_Goat_Profit / num_Cow_Goat;

            // Total profit for Sheep
            total_Sheep = sheepProfit - costs;

            // Average profit for sheep
            average_Sheep_Profit = total_Sheep / num_Sheep;

            //Display Method
            return ("Average Cow and Goat Profit: $" + average_Cow_Goat_Profit.ToString("F") +
                "\nAverage Sheep profit: $" + average_Sheep_Profit.ToString("F") +
                "\n\nCow, Goat VS Sheep Difference: $" + (average_Cow_Goat_Profit - average_Sheep_Profit).ToString("F"));

        }

        // Dog Costs, the cost of the dogs per day on the farm
        public static String getDogCosts()
        {
            double totalCost = getDailyCosts();
            double dogCost = 0;
            double dogRatio = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hashtable
            {
                // If animal is Dog calculate the dog costs
                if (animal.Value.a_Type.Equals("Dog"))
                {
                    dogCost = animal.Value.a_Daily_Cost + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3));
                }

            }
            // Ratio of costs of dogs compared to total costs(Dogs inclusive)
            dogRatio = dogCost / totalCost;

            return ("Dog Costs: $" + dogCost +
                "\nTotal Costs per day (Dogs Inclusive): $" + totalCost +
                "\n\nDog ratio over total cost: $" + dogRatio.ToString("F"));

        }

        // Ratio of red animals on the Animal_Farm
        public static String getRedRatio()
        {
            double redNum = 0;
            double animalNum = 0;
            double ratio = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hashtable
            {
                // If animal is the Colour "Red" Count them
                if (animal.Value.a_Colour.Equals("Red"))
                {
                    redNum++;
                }
                // Count animals as it checks all animals
                animalNum++;
            }

            // Ratio of Red animals compared with Total number of Animals
            ratio = redNum / animalNum;

            return ("The number of red animals on the farm: " + redNum +
                "\nTotal number of animals on the farm: " + animalNum +
                "\n\nRatio of Red VS Total amount of animals: " + (ratio * 100).ToString("F") + "%");

        }

        // To calculate the profitablity of the animals - Takes ID as a parameter
        public static double getProfitability(int id)
        {
            // Initializing Variables
            double profit = 0;
            double cost = 0;

            // Variable is here so I could use the debugger visibility of the ID that is going to be used from the parameters
            int a_id = id;


            //allAnimals[id]

            // If animal is not dog AND the ID is the same as the ID in the Hashtable
            // Used Hashtable to remove an extra for() to increase efficiency
            if (!allAnimals[id].a_Type.Equals("Dog") && id == allAnimals[id].a_ID)
            {
                // Calculate cost of all animals
                cost = allAnimals[id].a_Daily_Cost + (allAnimals[id].a_Weight * government_Tax) + (allAnimals[id].a_Amt_Water * Math.Pow(water_Price, 3));

                // Calculate cost IF they are Jersy Cows
                if (allAnimals[id].a_Type.Equals("Jersy Cow"))
                {
                    cost = allAnimals[id].a_Daily_Cost + (allAnimals[id].a_Weight * government_Tax) + (allAnimals[id].a_Amt_Water * Math.Pow(water_Price, 3) + jersey_Cow_Tax);
                }

                // Uses Dictionary(Value) getMilk/getWool function that overrides Animals_Farm getMilk/getWool - costs to calculate the profit
                switch (allAnimals[id].a_Type.ToString())
                {
                    // Uses switch case where these 3 fall under the same getMilk() method to reduce redundancy
                    case "Cow":
                    case "Jersy Cow":
                    case "Goat":
                        return (allAnimals[id].getMilk() - cost);
                    case "Sheep":
                        return(allAnimals[id].getWool() - cost);
                }
            }

            // Return the profit
            return (profit);
        }

        //Profit of the jersy Cows
        public static string getJersyCowProfit()
        {
            // Initializing Variables
            double cost = 0;
            double profit = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                // If Animal is Jersy Cow
                if (animal.Value.a_Type.Equals("Jersy Cow"))
                {
                    // Calculate the Costs, then Profit = milk from those Jersy Cows - costs
                    cost = animal.Value.a_Daily_Cost + (animal.Value.a_Weight * government_Tax) + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3)) + jersey_Cow_Tax;
                    profit = getCowMilkPerDay() - cost;
                }
            }
            return ("The Total Profit of All Jersy Cows: $ " + profit.ToString("F"));//Format to 2nd decimal point
        }

        // Finding the age of animals above a user entered limit
        public static String getAgeThreshold(int age)
        {
            double num_Animals = 0;
            double num_Limit = 0;
            double age_Ratio = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (animal.Value.a_Age >= age)
                {
                    num_Limit++;
                }
                num_Animals++;
            }

            age_Ratio = num_Limit / num_Animals;

            return ("The number of animals on the farm above: " + age + " is: " + num_Limit +
              "\nTotal number of animals on the farm: " + num_Animals +
              "\nRatio of age VS Total amount of animals: " + (age_Ratio * 100).ToString("F") + "%");
        }

        // To Generate a file
        public static void fileGenerator()
        {
            // Initializes Variables and array the size of dictionary counting all the animals
            int[] idArray = new int[allAnimals.Count];
            int index = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                // If animals are NOT Dog
                if (!animal.Value.a_Type.Equals("Dog"))
                {
                    // Then array Index = animal ID then increment index
                    idArray[index++] = animal.Value.a_ID;
                }
            }

             // Bubble Sort to sort through the array
             for (int i = 0; i < idArray.Length; i++)
             {
                 for (int j = 0; j < idArray.Length - 1; j++)
                 {
                    // Checks if id idex is == to 0 to make sure dogs dont appear, as the array is the count of allAnimals(19)
                    // If check passes then continue straight to the next if statement
                    if (idArray[j] == 0 || idArray[j + 1] == 0)
                        continue;

                    // If animal profitability associated with ID [J] is less than the profitability of the ID of [J + 1]
                    if (getProfitability(idArray[j]) < getProfitability(idArray[j + 1]))
                    {
                         int temp = idArray[j + 1];          // Sets temp as array J+1 index of array after J
                         idArray[j + 1] = idArray[j];        // Sets array J + 1 as J
                         idArray[j] = temp;                  // Sets array J as temp
                     }
                 }
             }


            // Writes to File in this location
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"D:\2018 Semester 2\COMP609 1802 - Application development\Animal Farm\DATABASE\ANIMAL_ID.txt"))
            {
                // For each Item(ID) in the array
                foreach (int item in idArray)
                {
                    // If statement to remove ID's that were 0 in the array(dog IDs were 0 because it counted allAnimals, but didnt insert the dogs)
                    if(item != 0)
                    {
                        // Write to file the ID + animal ID number + profitabilty of that ID for comparison reasons to prove its bean sorted
                        file.WriteLine("ID: " + item + "   Profit: "+ getProfitability(item));
                    }
                }
            }
        }// END OF fileGenerator




    }// END OF CLASS
}

