﻿namespace Animal_Farm
{
    partial class Animal_Farm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Age_Threshold_Button = new System.Windows.Forms.Button();
            this.Age_Threshold_Box = new System.Windows.Forms.TextBox();
            this.Age_Threshold_Label = new System.Windows.Forms.Label();
            this.Search_button = new System.Windows.Forms.Button();
            this.Search_Box = new System.Windows.Forms.TextBox();
            this.Search_Label = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Q12_Button = new System.Windows.Forms.Button();
            this.Q10_Button = new System.Windows.Forms.Button();
            this.Q9_Button = new System.Windows.Forms.Button();
            this.Q7_Button = new System.Windows.Forms.Button();
            this.Q6_Button = new System.Windows.Forms.Button();
            this.Q5_Button = new System.Windows.Forms.Button();
            this.Q4_Button = new System.Windows.Forms.Button();
            this.Q3_Button = new System.Windows.Forms.Button();
            this.Q2_Button = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.open_File_Button = new System.Windows.Forms.Button();
            this.Generate_File_Label = new System.Windows.Forms.Label();
            this.Q11_Button = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.Connect_Disconnect_Button = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Results = new System.Windows.Forms.DataGridView();
            this.Query_Text_Box = new System.Windows.Forms.TextBox();
            this.Query_Button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Results)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.tabControl1.Location = new System.Drawing.Point(0, -1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(10, 10);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(788, 439);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.Age_Threshold_Button);
            this.tabPage1.Controls.Add(this.Age_Threshold_Box);
            this.tabPage1.Controls.Add(this.Age_Threshold_Label);
            this.tabPage1.Controls.Add(this.Search_button);
            this.tabPage1.Controls.Add(this.Search_Box);
            this.tabPage1.Controls.Add(this.Search_Label);
            this.tabPage1.Location = new System.Drawing.Point(4, 48);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(780, 387);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Search";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // Age_Threshold_Button
            // 
            this.Age_Threshold_Button.Location = new System.Drawing.Point(219, 230);
            this.Age_Threshold_Button.Name = "Age_Threshold_Button";
            this.Age_Threshold_Button.Size = new System.Drawing.Size(137, 61);
            this.Age_Threshold_Button.TabIndex = 5;
            this.Age_Threshold_Button.Text = "Search";
            this.Age_Threshold_Button.UseVisualStyleBackColor = true;
            this.Age_Threshold_Button.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Search_Age_Mouse_Click);
            // 
            // Age_Threshold_Box
            // 
            this.Age_Threshold_Box.Location = new System.Drawing.Point(12, 230);
            this.Age_Threshold_Box.Multiline = true;
            this.Age_Threshold_Box.Name = "Age_Threshold_Box";
            this.Age_Threshold_Box.Size = new System.Drawing.Size(168, 61);
            this.Age_Threshold_Box.TabIndex = 4;
            // 
            // Age_Threshold_Label
            // 
            this.Age_Threshold_Label.AutoSize = true;
            this.Age_Threshold_Label.Location = new System.Drawing.Point(8, 180);
            this.Age_Threshold_Label.Name = "Age_Threshold_Label";
            this.Age_Threshold_Label.Size = new System.Drawing.Size(270, 24);
            this.Age_Threshold_Label.TabIndex = 3;
            this.Age_Threshold_Label.Text = "Please enter an Animal Age";
            // 
            // Search_button
            // 
            this.Search_button.Location = new System.Drawing.Point(219, 79);
            this.Search_button.Name = "Search_button";
            this.Search_button.Size = new System.Drawing.Size(137, 61);
            this.Search_button.TabIndex = 2;
            this.Search_button.Text = "Search";
            this.Search_button.UseVisualStyleBackColor = true;
            this.Search_button.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Search_button_MouseClick);
            // 
            // Search_Box
            // 
            this.Search_Box.Location = new System.Drawing.Point(12, 79);
            this.Search_Box.Multiline = true;
            this.Search_Box.Name = "Search_Box";
            this.Search_Box.Size = new System.Drawing.Size(168, 61);
            this.Search_Box.TabIndex = 1;
            // 
            // Search_Label
            // 
            this.Search_Label.AutoSize = true;
            this.Search_Label.Location = new System.Drawing.Point(8, 30);
            this.Search_Label.Name = "Search_Label";
            this.Search_Label.Size = new System.Drawing.Size(230, 24);
            this.Search_Label.TabIndex = 0;
            this.Search_Label.Text = "Search for an Animal ID";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.Q12_Button);
            this.tabPage2.Controls.Add(this.Q10_Button);
            this.tabPage2.Controls.Add(this.Q9_Button);
            this.tabPage2.Controls.Add(this.Q7_Button);
            this.tabPage2.Controls.Add(this.Q6_Button);
            this.tabPage2.Controls.Add(this.Q5_Button);
            this.tabPage2.Controls.Add(this.Q4_Button);
            this.tabPage2.Controls.Add(this.Q3_Button);
            this.tabPage2.Controls.Add(this.Q2_Button);
            this.tabPage2.Location = new System.Drawing.Point(4, 48);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(780, 387);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Farm Information";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Q12_Button
            // 
            this.Q12_Button.Location = new System.Drawing.Point(292, 253);
            this.Q12_Button.Name = "Q12_Button";
            this.Q12_Button.Size = new System.Drawing.Size(184, 93);
            this.Q12_Button.TabIndex = 9;
            this.Q12_Button.Text = "12. Total Profitability of Jersy Cows";
            this.Q12_Button.UseVisualStyleBackColor = true;
            this.Q12_Button.Click += new System.EventHandler(this.Q12_Button_Click);
            // 
            // Q10_Button
            // 
            this.Q10_Button.Location = new System.Drawing.Point(578, 140);
            this.Q10_Button.Name = "Q10_Button";
            this.Q10_Button.Size = new System.Drawing.Size(184, 93);
            this.Q10_Button.TabIndex = 7;
            this.Q10_Button.Text = "10. Total Tax for Jersy Cows";
            this.Q10_Button.UseVisualStyleBackColor = true;
            this.Q10_Button.Click += new System.EventHandler(this.Q10_Button_Click);
            // 
            // Q9_Button
            // 
            this.Q9_Button.Location = new System.Drawing.Point(388, 140);
            this.Q9_Button.Name = "Q9_Button";
            this.Q9_Button.Size = new System.Drawing.Size(184, 93);
            this.Q9_Button.TabIndex = 6;
            this.Q9_Button.Text = "9. Ratio of Red Animals";
            this.Q9_Button.UseVisualStyleBackColor = true;
            this.Q9_Button.Click += new System.EventHandler(this.Q9_Button_Click);
            // 
            // Q7_Button
            // 
            this.Q7_Button.Location = new System.Drawing.Point(198, 140);
            this.Q7_Button.Name = "Q7_Button";
            this.Q7_Button.Size = new System.Drawing.Size(184, 93);
            this.Q7_Button.TabIndex = 5;
            this.Q7_Button.Text = "7. Ratio of Dogs cost vs Total Cost";
            this.Q7_Button.UseVisualStyleBackColor = true;
            this.Q7_Button.Click += new System.EventHandler(this.Q7_Button_Click);
            // 
            // Q6_Button
            // 
            this.Q6_Button.Location = new System.Drawing.Point(8, 140);
            this.Q6_Button.Name = "Q6_Button";
            this.Q6_Button.Size = new System.Drawing.Size(184, 93);
            this.Q6_Button.TabIndex = 4;
            this.Q6_Button.Text = "6. Profitability of Goats and Cows Vs Sheep";
            this.Q6_Button.UseVisualStyleBackColor = true;
            this.Q6_Button.Click += new System.EventHandler(this.Q6_Button_Click);
            // 
            // Q5_Button
            // 
            this.Q5_Button.Location = new System.Drawing.Point(578, 21);
            this.Q5_Button.Name = "Q5_Button";
            this.Q5_Button.Size = new System.Drawing.Size(184, 93);
            this.Q5_Button.TabIndex = 3;
            this.Q5_Button.Text = "5. Average age(Dogs Excluded)";
            this.Q5_Button.UseVisualStyleBackColor = true;
            this.Q5_Button.Click += new System.EventHandler(this.Q5_Button_Click);
            // 
            // Q4_Button
            // 
            this.Q4_Button.Location = new System.Drawing.Point(388, 21);
            this.Q4_Button.Name = "Q4_Button";
            this.Q4_Button.Size = new System.Drawing.Size(184, 93);
            this.Q4_Button.TabIndex = 2;
            this.Q4_Button.Text = "4. Total Goat and Cow Milk per Day";
            this.Q4_Button.UseVisualStyleBackColor = true;
            this.Q4_Button.Click += new System.EventHandler(this.Q4_Button_Click);
            // 
            // Q3_Button
            // 
            this.Q3_Button.Location = new System.Drawing.Point(198, 21);
            this.Q3_Button.Name = "Q3_Button";
            this.Q3_Button.Size = new System.Drawing.Size(184, 93);
            this.Q3_Button.TabIndex = 1;
            this.Q3_Button.Text = "3. Tax Per Month";
            this.Q3_Button.UseVisualStyleBackColor = true;
            this.Q3_Button.Click += new System.EventHandler(this.Q3_Button_Click);
            // 
            // Q2_Button
            // 
            this.Q2_Button.Location = new System.Drawing.Point(8, 21);
            this.Q2_Button.Name = "Q2_Button";
            this.Q2_Button.Size = new System.Drawing.Size(184, 93);
            this.Q2_Button.TabIndex = 0;
            this.Q2_Button.Text = "2. Profitablity of the Farm per day";
            this.Q2_Button.UseVisualStyleBackColor = true;
            this.Q2_Button.Click += new System.EventHandler(this.Q2_Button_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.open_File_Button);
            this.tabPage3.Controls.Add(this.Generate_File_Label);
            this.tabPage3.Controls.Add(this.Q11_Button);
            this.tabPage3.Location = new System.Drawing.Point(4, 48);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(780, 387);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Generate File";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.label1.Location = new System.Drawing.Point(18, 222);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(749, 51);
            this.label1.TabIndex = 4;
            this.label1.Text = "                                                            File Location:\r\n\r\nD:\\" +
    "2018 Semester 2\\COMP609 1802 - Application development\\Animal Farm\\DATABASE\\ANIM" +
    "AL_ID.txt";
            // 
            // open_File_Button
            // 
            this.open_File_Button.Location = new System.Drawing.Point(409, 83);
            this.open_File_Button.Name = "open_File_Button";
            this.open_File_Button.Size = new System.Drawing.Size(184, 93);
            this.open_File_Button.TabIndex = 3;
            this.open_File_Button.Text = "Open File";
            this.open_File_Button.UseVisualStyleBackColor = true;
            this.open_File_Button.Click += new System.EventHandler(this.open_File_Button_Click);
            // 
            // Generate_File_Label
            // 
            this.Generate_File_Label.AutoSize = true;
            this.Generate_File_Label.Location = new System.Drawing.Point(222, 15);
            this.Generate_File_Label.Name = "Generate_File_Label";
            this.Generate_File_Label.Size = new System.Drawing.Size(285, 48);
            this.Generate_File_Label.TabIndex = 2;
            this.Generate_File_Label.Text = "Generate a File of animals ID \r\n ordered by their Profitability";
            // 
            // Q11_Button
            // 
            this.Q11_Button.Location = new System.Drawing.Point(131, 83);
            this.Q11_Button.Name = "Q11_Button";
            this.Q11_Button.Size = new System.Drawing.Size(184, 93);
            this.Q11_Button.TabIndex = 1;
            this.Q11_Button.Text = "Generate File";
            this.Q11_Button.UseVisualStyleBackColor = true;
            this.Q11_Button.Click += new System.EventHandler(this.Q11_Button_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.Connect_Disconnect_Button);
            this.tabPage4.Controls.Add(this.panel1);
            this.tabPage4.Controls.Add(this.Query_Text_Box);
            this.tabPage4.Controls.Add(this.Query_Button);
            this.tabPage4.Location = new System.Drawing.Point(4, 48);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(780, 387);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "SQL Queries";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // Connect_Disconnect_Button
            // 
            this.Connect_Disconnect_Button.Location = new System.Drawing.Point(512, 40);
            this.Connect_Disconnect_Button.Name = "Connect_Disconnect_Button";
            this.Connect_Disconnect_Button.Size = new System.Drawing.Size(131, 75);
            this.Connect_Disconnect_Button.TabIndex = 8;
            this.Connect_Disconnect_Button.Text = "Connect";
            this.Connect_Disconnect_Button.UseVisualStyleBackColor = true;
            this.Connect_Disconnect_Button.Click += new System.EventHandler(this.Connect_Disconnect_Button_Click_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Results);
            this.panel1.Location = new System.Drawing.Point(4, 121);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 266);
            this.panel1.TabIndex = 3;
            // 
            // Results
            // 
            this.Results.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Results.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Results.Location = new System.Drawing.Point(0, 0);
            this.Results.Name = "Results";
            this.Results.Size = new System.Drawing.Size(776, 266);
            this.Results.TabIndex = 2;
            // 
            // Query_Text_Box
            // 
            this.Query_Text_Box.Location = new System.Drawing.Point(4, 3);
            this.Query_Text_Box.Multiline = true;
            this.Query_Text_Box.Name = "Query_Text_Box";
            this.Query_Text_Box.Size = new System.Drawing.Size(493, 112);
            this.Query_Text_Box.TabIndex = 1;
            this.Query_Text_Box.Text = "SELECT * FROM Cow;";
            // 
            // Query_Button
            // 
            this.Query_Button.Location = new System.Drawing.Point(650, 40);
            this.Query_Button.Name = "Query_Button";
            this.Query_Button.Size = new System.Drawing.Size(127, 75);
            this.Query_Button.TabIndex = 0;
            this.Query_Button.Text = "Run Query";
            this.Query_Button.UseVisualStyleBackColor = true;
            this.Query_Button.Click += new System.EventHandler(this.Query_Button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.label2.Location = new System.Drawing.Point(503, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 34);
            this.label2.TabIndex = 9;
            this.label2.Text = "Connect/Disconnect\r\nTo the Database";
            // 
            // Animal_Farm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 444);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Animal_Farm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Animal Farm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Animal_Farm_FormClosing);
            this.Load += new System.EventHandler(this.Animal_Farm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Results)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button Search_button;
        private System.Windows.Forms.TextBox Search_Box;
        private System.Windows.Forms.Label Search_Label;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button Q2_Button;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button Age_Threshold_Button;
        private System.Windows.Forms.TextBox Age_Threshold_Box;
        private System.Windows.Forms.Label Age_Threshold_Label;
        private System.Windows.Forms.Button Q12_Button;
        private System.Windows.Forms.Button Q10_Button;
        private System.Windows.Forms.Button Q9_Button;
        private System.Windows.Forms.Button Q7_Button;
        private System.Windows.Forms.Button Q6_Button;
        private System.Windows.Forms.Button Q5_Button;
        private System.Windows.Forms.Button Q4_Button;
        private System.Windows.Forms.Button Q3_Button;
        private System.Windows.Forms.Label Generate_File_Label;
        private System.Windows.Forms.Button Q11_Button;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox Query_Text_Box;
        private System.Windows.Forms.Button Query_Button;
        private System.Windows.Forms.DataGridView Results;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button open_File_Button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Connect_Disconnect_Button;
        private System.Windows.Forms.Label label2;
    }
}

