﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace Animal_Farm
{
    class Rates_and_Prices// : Hashtable
    {
        /*
                SEPERATE "" UTILITY "" CLASS TO DO CALCULATIONS


        private static double goat_Milk_Price;     // Per litre (local currency)
        private static double cow_Milk_Price;      // Per litre (local currency)
        private static double sheep_Wool_Price;    // Per Kg (local currency)
        private static double water_Price;         // In Cube (local currency)
        private static double government_Tax;      // Per KG (not including dogs)
        private static double jersey_Cow_Tax;      // Per Jersy cow


        public Rates_and_Prices(int ID, double daily_Cost, double amt_water, double weight, int age, String colour, String type)
            : base(ID, daily_Cost, amt_water, weight, age, colour, type) // Generate constructor in hastable
        {

        }

        public static void getRates_Prices()
        {
            String connection_String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='H:\\2018 Semester 2\\COMP609 1802 - Application development\\DATABASE\\FarmInfomation.accdb';Persist Security Info=False";
            String error_message = "";

            //Stores the query
            String query = "";
            OleDbConnection connection = null;

            try
            {
                connection = new OleDbConnection(connection_String);
                connection.Open();
                query = "SELECT * FROM Rates;";
                OleDbCommand cnq = new OleDbCommand(query, connection);

                using (OleDbDataReader reader = cnq.ExecuteReader())
                {
                    while(reader.Read())
                    {
                        string commoditty = reader["Commodity"].ToString();
                        double price = double.Parse(reader["Price"].ToString());

                        // Requires static for object reference 
                        if(commoditty.Equals("Goat milk price"))
                        {
                            goat_Milk_Price = price;
                        }
                        if (commoditty.Equals("Sheep wool price"))
                        {
                            sheep_Wool_Price = price;
                        }
                        if (commoditty.Equals("water price"))
                        {
                            water_Price = price;
                        }
                        if (commoditty.Equals("Government tax per kg"))
                        {
                            government_Tax = price;
                        }
                        if (commoditty.Equals("Jersy cow tax"))
                        {
                            jersey_Cow_Tax = price;
                        }
                        if (commoditty.Equals("Cow milk price"))
                        {
                            cow_Milk_Price = price;
                        }
                    }
                }
                connection.Close();
            }
            catch(Exception ex)
            {
                error_message = ex.Message;
                Console.Write(error_message);
            }
        }

        // CalculatIons, the prices and everything else here.

        // Total Milk per day for the the farm animals
        public static String getMilkPerDay()
        {
            double totalMilk = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hastable
            {
                if (animal.Value.a_Type.Equals("Cow") || animal.Value.a_Type.Equals("Jersy Cow") || animal.Value.a_Type.Equals("Goat"))
                {
                    totalMilk += animal.Value.getZero();
                }
            }
            return ("Total Milk per day for Goats and Cows is: $" + totalMilk); 
        }

        // Total Milk per day for the Cows
        public static double getCowMilkPerDay()
        {
            double totalMilk = 0;
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hastable
            {
                if (animal.Value.a_Type.Equals("Cow"))
                {
                    totalMilk += animal.Value.getZero();
                }
            }
            return (totalMilk);
        }

        // Total Milk per day for the Goats
        public static double getGoatMilkPerDay()
        {
            double totalMilk = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hastable
            {
                if (animal.Value.a_Type.Equals("Goat"))
                {
                    totalMilk += animal.Value.getZero();
                }
            }
            return (totalMilk);
        }

        // Total Wool per day for the Sheep
        public static double getWoolPerDay()
        {
            double totalWool = 0;
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if(animal.Value.a_Type.Equals("Sheep"))
                {
                    totalWool += animal.Value.getZero();
                }
            }
            return (totalWool);
        }

        //Average Age of all Animals not including dogs
        public static String getAverageAge()
        {
            int averageAge = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (!animal.Value.a_Type.Equals("Dog"))
                {
                    averageAge += animal.Value.a_Age;
                }
            }
            return ("The Average Age of All Farm animals excluding dogs: " + averageAge);
        }

        // Calculates the daily cost + amount of water per day on the Animal_Farm
        public static double getDailyCosts()
        {
            double costsDaily = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                costsDaily += animal.Value.a_Daily_Cost + animal.Value.a_Amt_Water;
            }
            return (costsDaily);
        }

        // Gets total weight of the all the animals on the Animal_Farm
        public static double getTotalWeight()
        {
            double totalWeight = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                totalWeight += animal.Value.a_Weight;
            }
            return (totalWeight);
        }

        // Counts the number of Jersy Cows on the Animal_Farm
        public static double getNumberJersyCow()
        {
            int countJersyCow = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
               if(animal.Value.a_Type.Equals("Jersy Cow"))
                {
                    countJersyCow++;
                }
            }
            return (countJersyCow);
        }

        // Gets amount of water per day for each animal on the Animal_Farm
        public static double getWaterPerDay()
        {
            double amt_WaterPerDay = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                amt_WaterPerDay += animal.Value.a_Amt_Water;
            }
            return (amt_WaterPerDay);
        }


        // To Caluclate wheather the profit is in the green or the red (Positive, negative)
        public static String getProfitPerDay()
        {
            double totalCowMilk = getCowMilkPerDay() * cow_Milk_Price;

            double totalGoatMilk = getGoatMilkPerDay() * goat_Milk_Price;

            double totalMilk = totalCowMilk + totalGoatMilk;

            double totalWool = getWoolPerDay() * sheep_Wool_Price;

            double totalDailyCosts = getDailyCosts();

            double totalWeight = getTotalWeight() * government_Tax;

            double totalJersyCow = getNumberJersyCow() * jersey_Cow_Tax;

            double totalWater = getWaterPerDay() * Math.Pow(water_Price, 3);

            double GreenOrRed = (((totalMilk + totalWool) - (totalDailyCosts + totalWater)) - totalWeight) - totalJersyCow;

            if(GreenOrRed >= 0)
            {
                return ("Total Profit of the farm for Today is: $" + GreenOrRed);
            }
            else
            {
                return ("Total Loss of the farm for Today is: $" + GreenOrRed);
            }
            
        }

        public static String getTaxPerMonth()
        {
            double taxPerMonth = 0;
            
            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                taxPerMonth += ((getTotalWeight() * government_Tax) + (getNumberJersyCow() * jersey_Cow_Tax) * 30);// Find more accuarte way to calculate monthly
            }
            return ("Total Tax per Moth is: $" + taxPerMonth);
        }

        public static String getJersyCowTax()
        {
            double taxPerDay = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                taxPerDay += getNumberJersyCow() * jersey_Cow_Tax;
            }
            return ("Total Tax per day for Jersy Cows is: $" + taxPerDay);
        }

        // DO SOME TINKERING TO ALL THESE BELOW SO I CAN MAKE EM MY OWN

        // Comparing Cow and Goat against Sheep to find better profit margin
        public static String getCowGoatSheepProfit()
        {
            double costs = 0;
            double profit = 0;
            
            double total_Cow_Goat_Profit = 0;
            double average_Cow_Goat_Profit = 0;
            
            double total_Sheep = 0;
            double average_Sheep_Profit = 0;

            int num_Cow_Goat = 0;
            int num_Sheep = 0;


            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hastable
            {
                if (animal.Value.a_Type.Equals("Cow") || animal.Value.a_Type.Equals("Jersy Cow") || animal.Value.a_Type.Equals("Goat"))
                {
                    costs = animal.Value.a_Daily_Cost + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3)) + (animal.Value.a_Weight * government_Tax) + getNumberJersyCow();
                    profit = (getCowMilkPerDay() * cow_Milk_Price) + (getGoatMilkPerDay() * goat_Milk_Price);
                    num_Cow_Goat++;
                }
                else if(animal.Value.a_Type.Equals("Sheep"))
                {
                    costs = animal.Value.a_Daily_Cost + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3)) + (animal.Value.a_Weight * government_Tax);
                    profit = (getWoolPerDay() * sheep_Wool_Price);
                    num_Sheep++;
                }
            }

            total_Cow_Goat_Profit = profit - costs;

            average_Cow_Goat_Profit = total_Cow_Goat_Profit / num_Cow_Goat;

            total_Sheep = profit - costs;

            average_Sheep_Profit = total_Sheep / num_Sheep;

            return ("Average Cow and Goat Profit: $" + average_Cow_Goat_Profit +
                "\nAverage Sheep profit: $" + average_Sheep_Profit +
                "\nCow, Goat VS Sheep Difference: $" + (average_Cow_Goat_Profit - average_Sheep_Profit));

        }

        // Dog Costs, the cost of the dogs per day on the farm
        public static String getDogCosts()
        {
            double totalCost = getDailyCosts();
            double dogCost = 0;
            double dogRatio = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hastable
            {
                if (animal.Value.a_Type.Equals("Dog"))
                {
                    dogCost = animal.Value.a_Daily_Cost + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3));
                }

            }

            dogRatio = dogCost / totalCost;

            return ("Dog Costs: $" + dogCost +
                "\nTotal Costs per day (Dogs Inclusive): $" + totalCost +
                "\nDog ration over total cost: $" + dogRatio.ToString("F"));

        }
        // Ratio of red animals on the Animal_Farm
        public static String getRedRatio()
        {
            int redNum = 0;
            int animalNum = 0;
            double ratio = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals) // Inherits from hastable
            {
                if (animal.Value.a_Type.Equals("Red"))
                {
                    redNum++;
                }
                animalNum++;

            }
            ratio = redNum / animalNum;
            return ("The number of red animals on the farm: " + redNum +
                "\nTotal number of animals on the farm: " + animalNum +
                "\nRatio of Red VS Total amount of animals: " + (ratio*100).ToString("F") + "%");

        }
        //Profit of the jersy Cows
        public static string getJersyCowProfit()
        {
            double cost = 0;
            double profit = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (animal.Value.a_Type.Equals("Jersy Cow"))
                {
                    cost += animal.Value.a_Daily_Cost + (animal.Value.a_Weight * government_Tax) + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3)) + jersey_Cow_Tax;
                    profit = getCowMilkPerDay() - cost;
                }
            }
            return ("The Total Profit of All Jersy Cows: $ " + profit.ToString("F"));//Format to 2nd decimal point
        }
        // Finding the age of animals above a user entered limit
        public static String getAgeThreshold(int age)
        {
            double num_Animals = 0;
            double num_Limit = 0;
            double age_Ratio = 0;

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if(animal.Value.a_Age > age)
                {
                    num_Limit++;
                }
                num_Animals++;
            }

            age_Ratio = num_Limit / num_Animals;

            return ("The number of animals on the farm above: " + age + "is: " + num_Limit +
              "\nTotal number of animals on the farm: " + num_Animals +
              "\nRatio of age VS Total amount of animals: " + (age_Ratio * 100).ToString("F") + "%");
        }

        public static String fileGenerator()
        {
            double costs = 0;
            double profit = 0;

            int[] idArray = new int[allAnimals.Count];
            double[] profitArray = new double[allAnimals.Count];
            int index = 0;
            String message = "";

            foreach (KeyValuePair<int, Animals_Farm> animal in allAnimals)
            {
                if (animal.Value.a_Type.Equals("Cow"))
                {
                    profit = getCowMilkPerDay() - costs;
                    idArray[index] = animal.Value.a_ID;
                    profitArray[index] = profit;
                }

                if (animal.Value.a_Type.Equals("Jersy Cow"))
                {
                    costs += animal.Value.a_Daily_Cost + (animal.Value.a_Weight * government_Tax) + (animal.Value.a_Amt_Water * Math.Pow(water_Price, 3)) + jersey_Cow_Tax;
                }

                if (animal.Value.a_Type.Equals("Goat"))
                {
                    profit = getGoatMilkPerDay() - costs;
                    idArray[index] = animal.Value.a_ID;
                    profitArray[index] = profit;
                }

                if (animal.Value.a_Type.Equals("Sheep"))
                {
                    profit = getWoolPerDay() - costs;
                    idArray[index] = animal.Value.a_ID;
                    profitArray[index] = profit;
                }
                index++;
            }

            // Bubble Sort
            for(int i = 0; i < profitArray.Length; i++)
            {
                for(int j = 0; j < profitArray.Length-1; j++)
                {
                    if(profitArray[j] > profitArray[i])
                    {
                        double temp = profitArray[1 + j];
                        profitArray[j + 1] = profitArray[j];
                        profitArray[j] = temp;
                    }
                }
            }

            foreach(double item in profitArray)
            {
                message += "Porfit: " + item + "\n";
            }
            return("Size of array: " + profitArray.Length + "\n" + message);
        }

    */
    }//END OF CLASS   
}