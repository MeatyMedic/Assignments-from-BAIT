﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Assignment_App_Dev_proper_IDk
{
    class MultiThreading
    {/*
        
        int counter = 0;

        public static void addOne()
        {
            for (int i = 0; i < 10000; i++) counter++;
        }
        // Figure out how to connect multithreading with the rest of the program


        
        public static MultiThreading()
        {
            //Example 1
            counter = 0;
            ThreadStart threadStart = new ThreadStart(addOne);
            Thread thread1 = new Thread(threadStart);
            thread1.Start();
            while (thread1.IsAlive)
            {
                Thread.Sleep(5);
            }
            Console.WriteLine("The value of counter is: " + counter);
            Console.WriteLine("End of Example 1");

            // Bonus to add to the project, multithreading in the assignment.

            Thread thMain = Thread.CurrentThread;
            thMain.Name = "Main thread";
            Console.WriteLine("My name is : " + thMain.Name);
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        // i cant hear you!!!!!!!!! :(((((
        
        // MultiThreading without locking causes different outputs of the counter

        public static int counter;
        private static Object thisLock = new object(); // This adds lock method
        public static void addOne_2()
        {
            for (int i = 0; i < 10000; i++)
            {
                lock (thisLock)
                {
                    counter++;
                    Console.WriteLine("Thread 2: " + counter);
                }
            }
        }

        public static void addOne_1()
        {
            for (int i = 0; i < 100000; i++)
            {
                lock (thisLock)
                {
                    counter++;
                    Console.WriteLine("Thread 1: " + counter);
                }
            }
        }

        static void Main(string[] args)
        {
            counter = 0;
            ThreadStart threadStart_1 = new ThreadStart(addOne_1);
            Thread thread1 = new Thread(threadStart_1);
            thread1.Start();

            ThreadStart threadStart_2 = new ThreadStart(addOne_2);
            Thread thread2 = new Thread(threadStart_2);
            thread2.Start();

            while ((thread1.IsAlive) || (thread2.IsAlive))
            {
                Thread.Sleep(5);
            }

            Console.WriteLine("The Value of counter is: " + counter);
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            
        }*/
        

    }// end of Main
}// end of Class

    

