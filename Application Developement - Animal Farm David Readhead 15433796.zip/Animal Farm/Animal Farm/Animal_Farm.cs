﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_Farm
{
    class Animals_Farm  
    {
        // Have to inititalize to '0' Or I get Warnings about variables being defaulted to 0

        private int ID = 0;                // No duplicates
        private double amt_Water = 0;      // Per day
        private double weight = 0;         // In KG
        private int age = 0;               // In years
        private String colour;             // Colour of Animal e.g Red
        private double daily_Cost = 0;     // local currency
        private String type;               // Type of the animal

        // Public constructor for the Animals_Farm class
        public Animals_Farm(int ID, double amt_Water, double weight, int age, String colour, double daily_Cost, String type)
        {
            a_ID = ID;
            a_Amt_Water = amt_Water;
            a_Weight = weight;
            a_Age = age;
            a_Colour = colour;
            a_Daily_Cost = daily_Cost;
            a_Type = type;
        }

        // Method holder for getMilk, getWool, initialized as 0

        virtual public double getMilk()//set as this - Used for getting Milk
        {
            return (0);
        }

        virtual public double getWool()//set as this - Used for getting Wool
        {
            return (0);
        }


        // Getters and Setters
        public int a_ID { get; set; }
        public double a_Amt_Water { get; set; }
        public double a_Weight { get; set; }
        public int a_Age { get; set; }
        public double a_Daily_Cost { get; set; }

        // Make sure Colour cant have digits in it / Getter/setter
        public String a_Colour
        {
            get { return colour; }
            set
            {
                if (!value.Any(Char.IsDigit))
                {
                    colour = "No Colour ";
                }
                colour = value;
            }
        }

        // Make sure Type cant have digits in it / Getter/setter
        public String a_Type
        {
            get { return type; }
            set
            {
                if (!value.Any(Char.IsDigit))
                {
                    type = "No Type ";
                }
                type = value;
            }
        }

        //DisplayInfo Method
        virtual public String displayInfo()//displays all the info about the animal, display all the local variables to this class
        {
            return ("\n ID: " + ID +
             "\n Amount of Water: " + amt_Water +
             "\n Weight of the animal: " + weight +
             "\n Age of animal: " + age +
             "\n Colour of the animal: " + colour +
             "\n Daily cost of animals per day: " + daily_Cost +
             "\n Type of the animal: " + type);
        }
    }
}
