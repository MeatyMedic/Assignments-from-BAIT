﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_Farm
{
    class Jersey_Cow : Cows
    {
        // Show polymorphism through override and virtual
        // need fuction to test if jersey cow == true 

        // Public constructor for the Jersy Cow Class- Inherits from Cows and then Animals_Farm as it's parent classes
        public Jersey_Cow(int ID, double amt_water, double weight, int age, String colour, double daily_Cost, String type, double amt_CowMilk, bool is_jersey_cow)
         : base( ID,  amt_water,  weight,  age,  colour,  daily_Cost,  type, amt_CowMilk, is_jersey_cow)
        {
        }

        // Polymorhpism, Overrides Animals_Farm displayInfo() with this one if ID(Key) is related to this class
        override public String displayInfo()
        {
            return ("\n ID: " + a_ID +
             "\n Amount of Water: " + a_Amt_Water +
             "\n Weight of the animal: " + a_Weight +
             "\n Age of animal: " + a_Age +
             "\n Colour of the animal: " + a_Colour +
             "\n Daily cost of animals per day: " + a_Daily_Cost +
             "\n Type of the animal: " + a_Type +
             "\n Amount of Cow Milk: " + a_Amt_CowMilk +
             "\n Is the cow a Jersey Cow? " + a_Is_jersey_cow);
        }


    }
}
