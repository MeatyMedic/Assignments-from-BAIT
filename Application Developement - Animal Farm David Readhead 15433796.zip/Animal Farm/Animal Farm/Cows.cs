﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_Farm
{
    class Cows : Animals_Farm
    {
        public double a_Amt_CowMilk { get; set; }     // Per Day
        public bool a_Is_jersey_cow { get; set; }     // Boolean to check if cow is Jersy or not

        // Public constructor for the Cow Class- Inherits from Animals_Farm as it's parent class
        public Cows(int ID, double amt_water, double weight, int age, String colour, double daily_Cost, String type, double amt_CowMilk , bool is_jersey_cow)
         :base(ID, amt_water, weight, age, colour, daily_Cost, type)
        {
            // Declaring new types for constructor
            a_Amt_CowMilk = amt_CowMilk;
            a_Is_jersey_cow = is_jersey_cow;

        }

        // Overrides method in the Animal_Farm with this method, polymorphism
        override public double getMilk()
        {
            return (a_Amt_CowMilk);
        }

        // Polymorhpism, Overrides Animals_Farm displayInfo() with this one if ID(Key) is related to this class
        override public String displayInfo()
        {
            return ("\n ID: " + a_ID +
             "\n Amount of Water: " + a_Amt_Water +
             "\n Weight of the animal: " + a_Weight +
             "\n Age of animal: " + a_Age +
             "\n Colour of the animal: " + a_Colour +
             "\n Daily cost of animals per day: " + a_Daily_Cost +
             "\n Type of the animal: " + a_Type +
             "\n Amount of Cow Milk: " + a_Amt_CowMilk);
        }
    }
}
