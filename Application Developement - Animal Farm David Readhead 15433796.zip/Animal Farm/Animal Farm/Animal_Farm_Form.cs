﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Animal_Farm
{
    public partial class Animal_Farm : Form
    {
        // Sets up connection to the database
        String connection_String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='D:\\2018 Semester 2\\COMP609 1802 - Application development\\Animal Farm\\DATABASE\\FarmInfomation.accdb';Persist Security Info=False";
        String error_message = "";

        // Stores the query
        String query = "";

        // Sets default connection as null
        OleDbConnection connection = null;

        // Initializes Animal_Farm Form
        public Animal_Farm()
        {
            InitializeComponent();
        }

        // When Loading the Form

        private void Animal_Farm_Load(object sender, EventArgs e)
        {

            try
            {
                // Creating thread
                System.Threading.Thread genHashThread;

                // Creates an instance of the thread with the starting point being Hashtable.fileGenerator
                genHashThread = new System.Threading.Thread(new
                System.Threading.ThreadStart(Hashtable.generateHashTable));
                // Starts the Multithreading
                genHashThread.Start();
                

                // Then if Database works on Load, Generate hastable on loading of the main form
                Hashtable.generateHashTable();
                // Hashtable.allAnimals.Values.Count();
               // genHashThread.Abort();

               
                // Gets Rates and prices
                Hashtable.getRates_Prices();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //MessageBox.Show(Hashtable.getProfitPerDay());
        }

        // When Closing the Form
        private void Animal_Farm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Button to use method to Calculate the profit per day
        private void Q2_Button_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("" + Hashtable.counter());
            MessageBox.Show(Hashtable.getProfitPerDay());
        }

        // Button to use method to Calculate the tax per month
        private void Q3_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Hashtable.getTaxPerMonth());
        }

        // Button to use method to Calculate the Total Milk per day
        private void Q4_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Hashtable.getMilkPerDay());
        }

        // Button to use method to Calculate the Average age of all the animals(Dogs excluded)
        private void Q5_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Hashtable.getAverageAge());
        }

        // Button to use method to Calculate the Profit of Cows and Goats compared to just Sheep per day
        private void Q6_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Hashtable.getCowGoatSheepProfit());
        }

        // Button to use method to Calculate the Total Costs of the Dogs compared to rest of the animals per day
        private void Q7_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Hashtable.getDogCosts());
        }

        // Button to use method to Calculate the Ratio of Red animals on the farm compared to non red animals
        private void Q9_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Hashtable.getRedRatio());
        }

        // Button to use method to Calculate the Tax Paid for Jersy Cows
        private void Q10_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Hashtable.getJersyCowTax());
        }

        // Button to use method to Generate a File of Animals ID's ordered by each animals profitablity
        private void Q11_Button_Click(object sender, EventArgs e)
        {
            try
            {
                // Creating thread
                System.Threading.Thread genFileThread;

                // Creates an instance of the thread with the starting point being Hashtable.fileGenerator
                genFileThread = new System.Threading.Thread(new
                System.Threading.ThreadStart(Hashtable.fileGenerator));

                // Starts the Multithreading
                genFileThread.Start();
            }
            catch(Exception)
            {
                MessageBox.Show("File could not be generated!");
            }
        }

        // Button to use method to Calculate the Total Profitablity of Jersy Cows
        private void Q12_Button_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Hashtable.getJersyCowProfit());
        }

        // Button for Doing Query thats in the text box to show everything related to that query in table from from the database
        private void Query_Button_Click(object sender, EventArgs e)
        {
            error_message = "";
            query = Query_Text_Box.Text;
            try
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                OleDbDataAdapter adapter = new OleDbDataAdapter(command);

                DataTable dataTable = new DataTable();
                adapter.SelectCommand = command;
                adapter.Fill(dataTable);

                Results.DataSource = dataTable;
                //Results.AutoResizeColumn();
            }
            catch (Exception ex)
            {
                error_message = ex.Message;
                MessageBox.Show(error_message);
                MessageBox.Show("Please connect to the Database");
            }
        }

        // Button to use method to search for ID, and displayInfo() regarding the information related to the ID
        private void Search_button_MouseClick(object sender, MouseEventArgs e)
        {
            error_message = "";
            
            try
            {
                int id = int.Parse(Search_Box.Text);
                MessageBox.Show(Hashtable.getID(id));

            }
            catch(Exception ex)
            {
                error_message = ex.Message;
                MessageBox.Show(error_message);
            }
            Search_Box.Text = "";
        }

        // Button to use method to search for AgeThreshold, regarding the age inserted into the Adjacent textBox as its argument
        private void Search_Age_Mouse_Click(object sender, MouseEventArgs e)
        {
            try
            {
                int age = int.Parse(Age_Threshold_Box.Text);
                if(age < 0 )
                {
                    MessageBox.Show("Please enter a age that is Positive");
                }
                else
                {
                    MessageBox.Show(Hashtable.getAgeThreshold(age));
                }
                Age_Threshold_Box.Text = "";
            }
            catch(Exception ex)
            {
                error_message = ex.Message;
                MessageBox.Show(error_message);
                MessageBox.Show("Please enter a Valid age (Integer) ");
            }

        }

        // Button to open the file generated
        private void open_File_Button_Click(object sender, EventArgs e)
        {
            // Try and catch to make sure if there was no file to open, alert user there needs to be one created
            try
            {
                System.Diagnostics.Process.Start(@"D:\2018 Semester 2\COMP609 1802 - Application development\Animal Farm\DATABASE\ANIMAL_ID.txt");
            }
            catch(Exception)
            {
                MessageBox.Show("The file does not exist, please create one");
            }
        }

        // Gloabal variable for boolean to change the connect/disconnect function and the text of the button in real-time
        bool connected = false;
        // Button to connect/Disconect from the database
        private void Connect_Disconnect_Button_Click_1(object sender, EventArgs e)
        {


            if (connected == false)
            {
                connection = new OleDbConnection(connection_String);
                Connect_Disconnect_Button.Text = "Disconnect";
                connected = true;

            }
            else
            {
                Connect_Disconnect_Button.Text = "Connect";
                connected = false;

                connection.Close();
            }
        }




        // Accidental creation of tab
        private void tabPage4_Click(object sender, EventArgs e)
        {

        }
    }// END OF CLASS
}
