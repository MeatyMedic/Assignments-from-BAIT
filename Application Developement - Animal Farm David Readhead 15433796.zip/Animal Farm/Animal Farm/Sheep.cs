﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_Farm
{
    class Sheep : Animals_Farm
    {
        private double a_Amt_Wool { get; set; }        // Per day

        // Public constructor for the Sheep Class- Inherits from Animals_Farm as it's parent class
        public Sheep(int ID, double amt_water, double weight, int age, String colour, double daily_Cost, String type, double Amt_Wool)
    :   base(ID, amt_water, weight, age, colour, daily_Cost, type)
        {
            // Declaring new type for constructor
            a_Amt_Wool = Amt_Wool;
        }

        // Overrides method in the Animal_Farm with this method, polymorphism
        public override double getWool()
        {
            return(a_Amt_Wool);
        }

        // Polymorhpism, Overrides Animals_Farm displayInfo() with this one if ID(Key) is related to this class
        override public String displayInfo()
        {
            return ("\n ID: " + a_ID +
             "\n Amount of Water: " + a_Amt_Water +
             "\n Weight of the animal: " + a_Weight +
             "\n Age of animal: " + a_Age +
             "\n Colour of the animal: " + a_Colour +
             "\n Daily cost of animals per day: " + a_Daily_Cost +
             "\n Type of the animal: " + a_Type +
             "\n Amount of Sheep Wool: " + a_Amt_Wool);
        }
    }
}
