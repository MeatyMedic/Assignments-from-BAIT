package project1;
import static java.lang.System.out;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.*;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//question1();
		//question2();
		//question3();
		//question4();
		//question5();
		//question6();
		//question7();
		//question8();
	}
	static void question1()
	{
		String fmtemp = "%-30s%-30s\n";//fmtemp to create a temp as a variable.
		out.printf(fmtemp, "Escape Sequence", "Description");
		String spaceLine = String.format("%20s", "");//formats spaceLine into 20 white spaces
		String dashLine = spaceLine.replace(" ", "-");//replaces the 20 white spaces from spaceLine to 20 dashes in new string "dashLine"
		String dashLine2 = spaceLine.replace(" ", "-");//makes another dashLine to replace white spaces.
		out.printf(fmtemp, dashLine, dashLine2);//uses fmtemp and both dashLines to format the dashes

		out.printf(fmtemp, "\\n", "New Line Character");//displays \n
		out.printf(fmtemp, "\\t", "Horizontal Tab Character");//displays \t
		out.printf(fmtemp, "\\\"", "Double Quotes Character");//displays \""

	}

	static void question2()
	{
		//Scanner to get user input
		try(Scanner input = new Scanner(System.in))
		{
			out.print("Enter a radius please: ");//asks user question for input
			double radius = input.nextDouble();//converts user input to double for math

			double area = radius * radius *Math.PI;//area = input * input * pie
			double parameter = radius * 2 *Math.PI;//parameter = input * 2 * pie

			String fmtemp = "%-10s%-10s%-10s\n";//fmtemp to create a temp as a variable.
			out.printf(fmtemp, "Radius", "Area", "Parameter");//Strings to tell which number represents what
			String spaceLine = String.format("%30s", "");//formats spaceLine into 30 white spaces
			String dashLine = spaceLine.replace(" ", "-");//replaces the 30 white spaces from spaceLine to 30 dashes in new string "dashLine"
			out.println(dashLine);//makes dashes

			fmtemp = "%-10.2f%-10.2f%-10.2f\n";//redeclares the fmt statement for double floating point number
			out.printf(fmtemp, radius, area, parameter);//formats from fmtemp and has radius area and parameter

		}
	}
	static void question3()
	{
		try(Scanner input = new Scanner(System.in))
		{//gets user input
			String grade = "";
			out.print("Please enter a score: ");//asks for user input
			double score = input.nextDouble();//converts input to double


			String fmtemp = "%-10s%-10s\n";//formats strings
			out.printf(fmtemp, "Score", "Grade");
			String spaceLine = String.format("%15s", "");//formats 15 white spaces
			String dashLine = spaceLine.replace(" ", "-");//replaces 15 white spaces with dashes
			out.println(dashLine);//prints dashes

			if(score < 0 || score > 100)
			{//score outside range show error
				grade = "Grade Invalid, Please enter within range 0-100.";
			}
			else if(score >= 0 && score <= 49)
			{//Score in range show grade
				grade = "D";
			}
			else if(score >= 50 && score <= 69)
			{//Score in range show grade
				grade = "C";
			}
			else if(score >= 70 && score <= 79 )
			{//Score in range show grade
				grade = "B";
			}
			else if(score >= 80 && score <= 100)
			{//Score in range show grade
				grade = "A";
			}
			String fmtemp1 = "%-10.2f%-10s\n";//formats for 2 floating point and string
			out.printf(fmtemp1, score, grade);//prints score and grade

		}


	}
	static void question4()
	{
		try(Scanner input = new Scanner(System.in))//gets user input
		{
			out.println("Please enter a Play Card letter(J, Q, K, A): ");//asks for letter
			String card = input.nextLine().toLowerCase();
			String output = "";//initialing string :)

			while(true) {//if input is not this then do the else statement
				if(!(card.equals("J")) && !(card.equals("Q")) && !(card.equals("K")) && !(card.equals("A")))
				{
					out.println("Not what we asked!, please enter one of the suggested letters: ");
					card = input.nextLine().toLowerCase();//toLowerCase makes user input not case sensitive
				}

				else {
					//toLowerCase allows any case for user input
					switch(card){
						case "J":
							output = "Jack.";//output will be this if "J"
							break;// breaks out of switch statement if this is the output
						case "Q":
							output = "Queen.";//output will be this if "Q"
							break;// breaks out of switch statement if this is the output
						case "K":
							output = "King";//output will be this if "K"
							break;// breaks out of switch statement if this is the output
						case "A":
							output = "Ace.";//output will be this if "A"
							break;// breaks out of switch statement if this is the output
					}
					break;
				}
			}
			out.printf("Choice: %s\nCard: %s ",card, output);// prints the choice and cards
		}
	}

	static void question5()
	{
		try(Scanner input = new Scanner(System.in))//get user input
		{
			out.println("How many sensors are currently deployed? ");//asks how many sensors are there
			int sensors = input.nextInt();//user input becomes whole number

			double[] tempNums = new double [sensors];//makes array tempName and sets the length to the whole number that the user inputs

			int incNum = 1;//incrementing number
			int count = 0;//count to increment number
			double avg = 0;//initialization 0 for the average
			double max = 0;//initialization 0 for the max
			double sum = 0;//initialization 0 for the total

			for(int num = 0; num < tempNums.length; num++)//for loop that increments to be == the total length of the array(sensors)
			{
				out.printf("Please enter a Tempreture! #%d ", incNum);//asks for temperature
				double userTemp = input.nextDouble();//sets user input for temperatures as double
				tempNums[num] = userTemp;//stores the input from user in the array
				incNum++;//increments the number

				sum = sum + tempNums[num];//sum of all
				avg = sum / tempNums.length;//average of sum based on the length of array

				if(tempNums[num] > max) //stores the value of max in the array
				{
					max = tempNums[num];//max of the user input tempNums
				}

				if(tempNums[num] >= 10 && tempNums[num] <= 20)// index from tempNums to check if the entry is between 10 and 20
				{
					count++;//counts the entries
				}
			}
			out.printf("\nTemperature average: %.2f for %d sensors.", avg,sensors);//formats to show average and sensors
			out.printf("\nTemperature Max: %.2f", max);//shows the max tempNum
			out.printf("\nTemperatures between 10-20: %d", count);//shows the counted entries between 10 and 20
		}

	}
	static void question6()
	{
		List<String> cityList = new ArrayList();//Create String list to contain city names.
		cityList.add("Athens");
		cityList.add("Bangkok");
		cityList.add("Beijing");
		cityList.add("Berlin");
		cityList.add("Amsterdam");
		cityList.add("Ankara");

		List<String> countryList = new ArrayList();//Create String list to contain country names.
		countryList.add("Greece");
		countryList.add("Thailand");
		countryList.add("China");
		countryList.add("Germany");
		countryList.add("Netherlands");
		countryList.add("Turkey");


		int randoNum =ThreadLocalRandom.current().nextInt(0,6);//inclusive starts from 0 of the list and excludes 6 but includes the range of 0 - 5

		try(Scanner input = new Scanner(System.in))//gets user input
		{
			out.printf("Which country has the capital city %s?" //Ask a question to get user to :THONK:
					+ "\nEnter up to 3 names, comma-seperated: ", cityList.get(randoNum));//generate random city from cityList in string placeholder

			String userInput = input.nextLine();
			List<String> userInputSplit = new ArrayList<String>(Arrays.asList(userInput.split(", ")));//splits the list
			//out.println(userInputSplit);


			while(true)
			{//while loop to check user input length for the List
				if(userInputSplit.size() >3)//if input is greater than 3
				{
					out.println("\nSorry, only 3 names are allowed! ");//print this line

					out.printf("Which country has the capital city %s?" //Ask a question to get user to :THONK:
							+ "\nEnter up to 3 names, comma-seperated: ", cityList.get(randoNum));//generate random city from cityList in string placeholder

					userInput = input.nextLine();//stores the user input
					userInputSplit = new ArrayList<String>(Arrays.asList(userInput.split(", ")));//splits the list with comma white space (, )

				}
				else//else do this
				{
					String answer = "";//placeholder for string
					out.printf("The country is %s\n", countryList.get(randoNum));//generate random country from countryList in string placeholder


					for(String u : userInputSplit)//for each of the strings in userInputSplit List
					{
						if(u.equals(countryList.get(randoNum)))//random countryList number
								{
									answer = "Congratulations, your answer is correcto!.";//gives output line if its correct
									break;//breaks after print
								}
						else {
							answer = "The answer given is wrong sorry :(";//else print this, if answer is wrong
						}
					}
					out.println(answer);//gives this is answer is correct
					break;//break ends it all
				}
			}
		}


	}
	static void question7()
	{
		try(Scanner input = new Scanner(System.in))
		{//request user input for numbers
			out.println("Enter the first line of comma-separated numbers:");//prints this line for user to read

			String userNums = input.nextLine();//stores the user input
			List<String> userNumSplit = new ArrayList<String>(Arrays.asList(userNums.split(", ")));//splits the list

			out.println("Enter the first line of comma-separated numbers:");

			String userNums2 = input.nextLine();//stores the user input
			List<String> userNumSplit2 = new ArrayList<String>(Arrays.asList(userNums2.split(", ")));//splits the list

			int numCount = 0;//initialization number for count

			for(String N : userNumSplit)
			{//For each of the strings in the first List
				double userNumsDouble = Double.parseDouble(N);//conversion from String to Double then store it in userNumsDouble
				for(String M : userNumSplit2)
				{//Same, For each of the strings in the second List
					double userNumsDouble2 = Double.parseDouble(M);//conversion from String to double then store it in userNumDouble
					if(userNumsDouble == userNumsDouble2)
					{
						numCount++;
					}
				}
			} out.printf("The number of overlapping numbers: %d", numCount);//print in formatting of numCount in the placeholder %d for double
		}
	}
	static void question8()
	{
		try(Scanner input = new Scanner(System.in))
		{//scanner to get user input
			out.println("Please enter a line of comma-separated temperatures: ");//asks for user input

			String userTemperature = input.nextLine();//stores the user input
			List<String> userTempSplit = new ArrayList<String>(Arrays.asList(userTemperature.split(", ")));//splits the list

			int tempCount = 0;//Initialization for all of these
			double avg = 0;
			double max = 0;
			double sum = 0;

			for(String T : userTempSplit)
			{//for loop to convert and calculate temperatures
				double temperatureDouble = Double.parseDouble(T);//conversion from String to Double then store it in temperatureDouble
				sum = sum + temperatureDouble;//total = all the values added together
				avg = sum / userTempSplit.size();//average = sum divided by size of the list
				if(temperatureDouble > max)
				{//if temperature is larger than max
					max = temperatureDouble;//max is then stored
				}
				if(temperatureDouble >= 0 && temperatureDouble <= 10)
				{// if temperature is between 0 and 10
					tempCount++;//count all temperatures that are
				}
			} out.printf("The Average Temperature is: %.2f \n", avg);//display what the average temperature is
			  out.printf("The Max Temperature is: %.2f \n", max);//display what the max temperature was
			  out.printf("Temperatures that are between 0 and 10: %d \n", tempCount);//count all the temperatures from the list that were between the range 0 - 10
		}
	}
}